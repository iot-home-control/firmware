#ifndef IPAddress_h
#define IPAddress_h

extern "C" {

#define IPAddress uint8_t*  

}


#endif
